import { GoogleGenAI, Type } from "@google/genai";
import type { QuranVerb } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    arabicVerb: {
      type: Type.STRING,
      description: "The original Arabic verb provided by the user.",
    },
    malayalamMeaning: {
      type: Type.STRING,
      description: "The precise Malayalam meaning of the verb.",
    },
    rootLetters: {
      type: Type.STRING,
      description: "The three-letter Arabic root (shars) of the verb.",
    },
    verses: {
      type: Type.ARRAY,
      description: "Up to 3 examples of Quranic verses where this verb or its derivatives are used.",
      items: {
        type: Type.OBJECT,
        properties: {
          verseReference: {
            type: Type.STRING,
            description: "The reference of the verse, e.g., 'Surah Al-Baqarah (2:25)'.",
          },
          arabicText: {
            type: Type.STRING,
            description: "The full Arabic text of the verse.",
          },
          transliteration: {
            type: Type.STRING,
            description: "The English transliteration of the Arabic verse.",
          },
          malayalamTranslation: {
            type: Type.STRING,
            description: "The Malayalam translation of the verse.",
          },
        },
        required: ["verseReference", "arabicText", "transliteration", "malayalamTranslation"],
      },
    },
  },
  required: ["arabicVerb", "malayalamMeaning", "rootLetters", "verses"],
};

export const getVerbMeaning = async (verb: string): Promise<QuranVerb> => {
  try {
    const prompt = `
      Analyze the Quranic Arabic verb: "${verb}".
      
      Provide the following information:
      1.  The Malayalam meaning of this verb.
      2.  The three-letter Arabic root (shars) for this verb.
      3.  Find up to three distinct verses from the Holy Quran where this verb or a word derived from its root appears. For each verse, provide the full Arabic text, its English transliteration, its Malayalam translation, and the verse reference (Surah name, chapter:verse number).

      Ensure your response strictly follows the provided JSON schema. 
      - If the verb is not found or is invalid, the 'verses' array should be empty and the malayalamMeaning should indicate that it was not found.
      - If the verb is valid but no Quranic examples can be found, return the meaning and root letters with an empty 'verses' array.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.2,
      },
    });

    const jsonText = response.text.trim();
    // Clean potential markdown formatting from the response
    const cleanedJsonText = jsonText.replace(/^```json\s*/, '').replace(/```$/, '');
    const parsedData: QuranVerb = JSON.parse(cleanedJsonText);

    if (!parsedData.malayalamMeaning) {
        throw new Error("The API response did not contain a meaning for the verb.");
    }

    return parsedData;

  } catch (error) {
    console.error("Error fetching data from Gemini API:", error);
    if (error instanceof SyntaxError) {
      throw new Error("Failed to parse the API response. The format was invalid.");
    }
    // Re-throw other errors to be handled by the caller
    throw new Error("Could not retrieve the meaning from the API.");
  }
};