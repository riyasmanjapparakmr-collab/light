
import React from 'react';
import type { DetailedVerb } from '../types';

interface ExampleVerbsProps {
    verbs: DetailedVerb[];
    onVerbSelect: (verb: string) => void;
}

const ExampleVerbs: React.FC<ExampleVerbsProps> = ({ verbs, onVerbSelect }) => {
    if (verbs.length === 0) {
        return null;
    }

    return (
        <div className="mt-4 p-4">
            <h3 className="text-md font-semibold text-slate-400 mb-3 text-center sm:text-left">
                Common Verbs (ഉദാഹരണങ്ങൾ)
            </h3>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3">
                {verbs.map((item) => (
                    <button
                        key={item.root_verb}
                        onClick={() => onVerbSelect(item.root_verb)}
                        dir="rtl"
                        lang="ar"
                        className="px-4 py-2 bg-slate-700 text-slate-200 text-xl font-serif rounded-full hover:bg-cyan-600 hover:text-white transition-colors duration-300"
                        title={item.meaning}
                    >
                        {item.root_verb}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default ExampleVerbs;
