
import React from 'react';
import { SearchIcon } from './icons';

interface VerbInputProps {
  verb: string;
  setVerb: (verb: string) => void;
  onSearch: () => void;
  isLoading: boolean;
}

const VerbInput: React.FC<VerbInputProps> = ({ verb, setVerb, onSearch, isLoading }) => {
  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      onSearch();
    }
  };
  
  return (
    <div className="flex items-center gap-2 p-2 bg-slate-800 rounded-lg shadow-lg border border-slate-700 focus-within:ring-2 focus-within:ring-cyan-500 transition-all duration-300">
      <input
        type="text"
        dir="rtl"
        lang="ar"
        value={verb}
        onChange={(e) => setVerb(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="...فعل"
        className="w-full bg-transparent text-2xl text-right text-slate-100 placeholder-slate-500 focus:outline-none px-4 py-2"
        disabled={isLoading}
      />
      <button
        onClick={onSearch}
        disabled={isLoading}
        className="flex items-center justify-center gap-2 px-6 py-3 bg-cyan-600 text-white font-semibold rounded-md hover:bg-cyan-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500"
      >
        <SearchIcon className="h-5 w-5" />
        <span>Search</span>
      </button>
    </div>
  );
};

export default VerbInput;
