
import React from 'react';
import type { DetailedVerb, TenseConjugations } from '../types';

interface ConjugationTableProps {
  verbData: DetailedVerb;
}

// Define a more specific type for the keys that map to TenseConjugations to ensure type safety.
type TenseKey = 'past_tense' | 'present_tense' | 'imperative';

const tenseData: { key: TenseKey; name: string }[] = [
    { key: 'past_tense', name: 'Past Tense (ഭൂതകാലം)' },
    { key: 'present_tense', name: 'Present Tense (വർത്തമാനകാലം)' },
    { key: 'imperative', name: 'Imperative (കല്പന ക്രിയ)' },
];

const formData: { key: keyof TenseConjugations, name: string}[] = [
    { key: 'singular_masculine', name: 'Singular Masculine' },
    { key: 'plural_masculine', name: 'Plural Masculine' },
    { key: 'singular_feminine', name: 'Singular Feminine' },
    { key: 'plural_feminine', name: 'Plural Feminine' },
];


const ConjugationTable: React.FC<ConjugationTableProps> = ({ verbData }) => {
  return (
    <div className="bg-slate-800 p-4 sm:p-6 rounded-lg shadow-lg border border-slate-700">
        <h3 className="text-2xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-500 border-b-2 border-slate-700 pb-2">
            Detailed Conjugations
        </h3>
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                <thead className="border-b-2 border-slate-600">
                    <tr>
                        <th className="p-3 text-sm font-semibold tracking-wider text-slate-300">Tense</th>
                        <th className="p-3 text-sm font-semibold tracking-wider text-slate-300">Form</th>
                        <th className="p-3 text-sm font-semibold tracking-wider text-slate-300 text-right">Arabic</th>
                        <th className="p-3 text-sm font-semibold tracking-wider text-slate-300">Malayalam</th>
                    </tr>
                </thead>
                <tbody>
                    {tenseData.map((tense) => {
                        const conjugations = verbData[tense.key];
                        return (
                            <React.Fragment key={tense.key}>
                                {formData.map((form, formIndex) => (
                                    <tr key={`${tense.key}-${form.key}`} className="border-b border-slate-700 last:border-none">
                                        {formIndex === 0 && (
                                            <td rowSpan={4} className="p-3 align-top font-semibold text-cyan-400 border-r border-slate-700">
                                                {tense.name}
                                            </td>
                                        )}
                                        <td className="p-3 text-slate-400">{form.name}</td>
                                        <td className="p-3 text-2xl text-right font-serif text-slate-100" dir="rtl" lang="ar">
                                            {conjugations[form.key].arabic}
                                        </td>
                                        <td className="p-3 text-slate-200">{conjugations[form.key].malayalam}</td>
                                    </tr>
                                ))}
                            </React.Fragment>
                        );
                    })}
                </tbody>
            </table>
        </div>
    </div>
  );
};

export default ConjugationTable;
