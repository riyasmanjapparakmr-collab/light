
import React from 'react';
import type { QuranVerb, QuranVerseExample, DetailedVerb } from '../types';
import { LoadingSpinner } from './icons';
import ConjugationTable from './ConjugationTable';

interface ResultDisplayProps {
  result: QuranVerb | null;
  detailedVerb: DetailedVerb | null;
  isLoading: boolean;
  error: string | null;
}

const InitialState: React.FC = () => (
    <div className="text-center p-8 mt-6">
        <p className="text-slate-400">
            Type a verb from the Quran in the search box to see its Malayalam meaning and examples.
        </p>
    </div>
);

const VerseCard: React.FC<{ verse: QuranVerseExample }> = ({ verse }) => (
    <div className="bg-slate-800 border border-slate-700 p-4 rounded-lg space-y-3 transition-transform duration-300 hover:scale-[1.02] hover:border-cyan-500">
        <p className="text-lg font-semibold text-cyan-400">{verse.verseReference}</p>
        <p dir="rtl" lang="ar" className="text-2xl text-right font-serif text-slate-100 leading-loose">{verse.arabicText}</p>
        <p className="text-slate-400 italic">{verse.transliteration}</p>
        <p className="text-slate-200">{verse.malayalamTranslation}</p>
    </div>
);

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, detailedVerb, isLoading, error }) => {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center mt-6 p-8 bg-slate-800/50 border border-slate-700 rounded-lg">
        <LoadingSpinner className="h-12 w-12 text-cyan-500" />
        <p className="mt-4 text-lg text-slate-300 animate-pulse">Searching the depths of the Quran...</p>
      </div>
    );
  }

  if (!result && !error && !detailedVerb) {
    return <InitialState />;
  }

  return (
    <div className="mt-6 space-y-8 animate-fade-in">
      {error && (
        <div className="p-4 bg-red-900/20 border border-red-500 rounded-lg text-center">
          <p className="text-red-400 font-semibold">{error}</p>
        </div>
      )}

      {result && (
        <>
          <div className="bg-slate-800 p-6 rounded-lg shadow-lg border border-slate-700">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                      <h2 className="text-4xl text-right text-slate-100 font-bold font-serif" dir="rtl">{result.arabicVerb}</h2>
                      <p className="text-xl text-teal-400 font-semibold mt-2">{result.malayalamMeaning}</p>
                  </div>
                  <div className="bg-slate-700 px-4 py-2 rounded-full">
                      <p className="text-slate-300">Root: <span className="font-bold text-lg text-amber-400 font-serif" dir="rtl">{result.rootLetters}</span></p>
                  </div>
              </div>
          </div>
        </>
      )}

      {detailedVerb && (
        <ConjugationTable verbData={detailedVerb} />
      )}
      
      {result && result.verses.length > 0 && (
         <div>
            <h3 className="text-2xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-500 border-b-2 border-slate-700 pb-2">
                Usage in Quran
            </h3>
            <div className="space-y-4">
                {result.verses.map((verse, index) => (
                    <VerseCard key={index} verse={verse} />
                ))}
            </div>
        </div>
      )}
    </div>
  );
};

export default ResultDisplay;
