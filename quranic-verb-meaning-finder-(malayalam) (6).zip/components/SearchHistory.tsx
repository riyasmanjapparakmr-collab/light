
import React from 'react';
import { TrashIcon } from './icons';

interface SearchHistoryProps {
    history: string[];
    onHistorySelect: (verb: string) => void;
    onClearHistory: () => void;
}

const SearchHistory: React.FC<SearchHistoryProps> = ({ history, onHistorySelect, onClearHistory }) => {
    if (history.length === 0) {
        return null;
    }

    return (
        <div className="mt-4 p-4">
            <div className="flex justify-between items-center mb-3">
                <h3 className="text-md font-semibold text-slate-400 text-center sm:text-left">
                    Search History (ചരിത്രം)
                </h3>
                {history.length > 0 && (
                    <button
                        onClick={onClearHistory}
                        className="flex items-center gap-1 text-slate-500 hover:text-red-400 transition-colors duration-200"
                        title="Clear history"
                        aria-label="Clear search history"
                    >
                        <TrashIcon className="h-4 w-4" />
                        <span className="text-sm">Clear</span>
                    </button>
                )}
            </div>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3">
                {history.map((verb) => (
                    <button
                        key={verb}
                        onClick={() => onHistorySelect(verb)}
                        dir="rtl"
                        lang="ar"
                        className="px-4 py-2 bg-slate-700 text-slate-200 text-xl font-serif rounded-full hover:bg-cyan-600 hover:text-white transition-colors duration-300"
                    >
                        {verb}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default SearchHistory;
